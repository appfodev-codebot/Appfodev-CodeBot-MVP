# Appfodev CodeBot MVP

## Setup Instructions

### 1. Install Dependencies
Run the following command to install required packages:
```bash
pip install flask openai pymongo flask-bcrypt flask-jwt-extended python-dotenv
```

### 2. Configure Environment Variables
Create a `.env` file in the project directory and add the following:
```ini
OPENAI_API_KEY=your_openai_api_key
MONGO_URI=mongodb://localhost:27017/
JWT_SECRET_KEY=your_secret_key
```

### 3. Start the Flask Server
Run the Flask API:
```bash
python main_updated.py
```

### 4. API Endpoints
- **Register User**: `POST /register` (username, password)  
- **Login**: `POST /login` (username, password) → Returns JWT token  
- **Generate Code**: `POST /generate-code` (requires JWT token)  
- **Retrieve History**: `GET /history` (requires JWT token)  

### Notes
- Ensure MongoDB is running locally or provide a valid `MONGO_URI`.
- Replace `OPENAI_API_KEY` with your actual OpenAI API key.
